﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Temporary.Models;

namespace Temporary.Services
{
    public interface IAssetService
    {
        public Asset getAssetForUser(int userId);
        public int AddAssetToUser(Asset asset, User user);

    }
    public class AssetService
    {
        public Asset getAssetForUser(int userId)
        {
            return null;
        }
    }
}
