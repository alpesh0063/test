﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Temporary.Models
{
    public class Printer
    {
        [Key]
        public int ID { get; set; }
        public int pagePerMinute { get; set; }
        public int location { get; set; }
    }
}
