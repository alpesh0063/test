﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Temporary.Models
{
    public class Computer
    {
        public int ID { get; set; }
        public int cpu { get; set; }
        public int ram { get; set; }

    }
}
