﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Temporary.Models
{
    public class Asset
    {
        public string id;
        public string name { get; set; }
        public string type { get; set; }
        public int originalAssetValue { get; set; }

        public int years { get; set; }
        public int currentAssetValue => (int)(originalAssetValue * Math.Pow(0.8,years));
        public string status { get; set; }
        public int computerID { get; set; }
        [ForeignKey("computerId")]
        public virtual Computer computer { get; set; }

        public int printerId { get; set; }
        [ForeignKey("printerId")]
        public virtual Printer printer { get; set; }
    }
}
